package view;

import controller.ReservationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Room;

import java.util.List;

public class ViewSpacesView {

    private final ReservationController reservationController;

    public ViewSpacesView(
            ReservationController reservationController
    ) {
        this.reservationController =
                reservationController;
    }

    public void show(Stage stage) {

        Label title =
                new Label(
                        "View Spaces"
                );

        title.setStyle(
                Theme.TITLE
        );

        Label filterLabel =
                new Label(
                        "Minimum Capacity:"
                );

        filterLabel.setStyle(
                Theme.BOLD_LABEL
        );

        TextField capacityField =
                new TextField();

        capacityField.setPromptText(
                "Enter minimum capacity"
        );

        capacityField.setPrefSize(
                260,
                45
        );

        capacityField.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        Button filterButton =
                new Button(
                        "Filter"
                );

        Button clearButton =
                new Button(
                        "Clear"
                );

        filterButton.setPrefSize(
                150,
                45
        );

        clearButton.setPrefSize(
                150,
                45
        );

        Theme.stylePrimaryButton(
                filterButton
        );

        Theme.styleBackButton(
                clearButton
        );

        HBox filterControls =
                new HBox(
                        15,
                        capacityField,
                        filterButton,
                        clearButton
                );

        filterControls.setAlignment(
                Pos.CENTER
        );

        VBox filterPanel =
                new VBox(
                        12,
                        filterLabel,
                        filterControls
                );

        filterPanel.setAlignment(
                Pos.CENTER
        );

        filterPanel.setPadding(
                new Insets(20)
        );

        filterPanel.setMaxWidth(
                700
        );

        filterPanel.setStyle(
                "-fx-background-color: rgba(255,255,255,0.08);" +
                        "-fx-background-radius: 18px;" +
                        "-fx-border-color: " + Theme.RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 18px;"
        );

        VBox roomContainer =
                new VBox(
                        18
                );

        roomContainer.setAlignment(
                Pos.CENTER
        );

        showRooms(
                stage,
                roomContainer,
                reservationController
                        .getAllRooms()
        );

        filterButton.setOnAction(e -> {

            String text =
                    capacityField
                            .getText()
                            .trim();

            if (text.isEmpty()) {

                showError(
                        "Missing Capacity",
                        "Please enter a minimum capacity."
                );

                return;
            }

            try {

                int minimumCapacity =
                        Integer.parseInt(
                                text
                        );

                if (minimumCapacity < 0) {

                    showError(
                            "Invalid Capacity",
                            "Capacity cannot be negative."
                    );

                    return;
                }

                List<Room> rooms =
                        reservationController
                                .getRoomsByCapacity(
                                        minimumCapacity
                                );

                showRooms(
                        stage,
                        roomContainer,
                        rooms
                );

            } catch (
                    NumberFormatException ex
            ) {

                showError(
                        "Invalid Capacity",
                        "Please enter a whole number."
                );
            }
        });

        clearButton.setOnAction(e -> {

            capacityField.clear();

            showRooms(
                    stage,
                    roomContainer,
                    reservationController
                            .getAllRooms()
            );
        });

        ScrollPane scrollPane =
                new ScrollPane(
                        roomContainer
                );

        scrollPane.setFitToWidth(
                true
        );

        scrollPane.setPrefHeight(
                600
        );

        scrollPane.setStyle(
                "-fx-background: transparent;" +
                        "-fx-background-color: transparent;"
        );

        Button backButton =
                new Button(
                        "Back to Main Menu"
                );

        backButton.setPrefSize(
                300,
                55
        );

        Theme.styleBackButton(
                backButton
        );

        backButton.setOnAction(e ->

                new MainView(
                        reservationController
                ).show(stage)
        );

        VBox layout =
                new VBox(
                        25,
                        title,
                        filterPanel,
                        scrollPane,
                        backButton
                );

        layout.setAlignment(
                Pos.CENTER
        );

        layout.setPadding(
                new Insets(40)
        );

        layout.setStyle(
                Theme.BACKGROUND
        );

        Scene scene =
                new Scene(
                        layout,
                        1500,
                        1000
                );

        stage.setTitle(
                "View Spaces"
        );

        stage.setScene(scene);
        stage.show();
    }

    private void showRooms(
            Stage stage,
            VBox roomContainer,
            List<Room> rooms
    ) {

        roomContainer
                .getChildren()
                .clear();

        if (rooms.isEmpty()) {

            Label noRooms =
                    new Label(
                            "No spaces match the selected capacity."
                    );

            noRooms.setStyle(
                    Theme.BOLD_LABEL
            );

            roomContainer
                    .getChildren()
                    .add(noRooms);

            return;
        }

        for (Room room : rooms) {

            roomContainer
                    .getChildren()
                    .add(
                            createRoomCard(
                                    stage,
                                    room
                            )
                    );
        }
    }

    private VBox createRoomCard(
            Stage stage,
            Room room
    ) {

        Label roomName =
                new Label(
                        room.getName()
                );

        roomName.setStyle(
                Theme.CARD_TITLE
        );

        Label roomNumber =
                new Label(
                        "Room: " +
                                room.getRoomNumber()
                );

        roomNumber.setStyle(
                Theme.CARD_TEXT
        );

        Label building =
                new Label(
                        "Building: " +
                                room.getBuilding()
                );

        building.setStyle(
                Theme.CARD_TEXT
        );

        Label capacity =
                new Label(
                        "Capacity: " +
                                room.getCapacity()
                );

        capacity.setStyle(
                Theme.CARD_TEXT
        );

        Label features =
                new Label(
                        "Features: " +
                                String.join(
                                        ", ",
                                        room.getFeatures()
                                )
                );

        features.setStyle(
                Theme.CARD_TEXT
        );

        features.setWrapText(
                true
        );

        Button detailsButton =
                new Button(
                        "View Details"
                );

        detailsButton.setPrefSize(
                180,
                45
        );

        Theme.styleButton(
                detailsButton,
                "#D6D6D6",
                "#111111",
                Theme.RED,
                Theme.WHITE
        );

        detailsButton.setOnAction(e ->

                new SpaceDetailsView(
                        reservationController
                ).show(
                        stage,
                        room
                )
        );

        VBox card =
                new VBox(
                        10,
                        roomName,
                        roomNumber,
                        building,
                        capacity,
                        features,
                        detailsButton
                );

        card.setAlignment(
                Pos.CENTER
        );

        card.setPadding(
                new Insets(25)
        );

        card.setMaxWidth(
                750
        );

        card.setStyle(
                "-fx-background-color: white;" +
                        "-fx-background-insets: 4;" +
                        "-fx-background-radius: 8px;" +
                        "-fx-border-color: " + Theme.RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 12px;" +
                        "-fx-border-insets: 0;"
        );

        return card;
    }

    private void showError(
            String title,
            String message
    ) {

        Alert alert =
                new Alert(
                        Alert.AlertType.ERROR
                );

        alert.setTitle(
                title
        );

        alert.setHeaderText(
                null
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }
}