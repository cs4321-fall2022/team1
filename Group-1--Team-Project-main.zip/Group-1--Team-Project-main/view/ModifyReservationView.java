package view;

import controller.ReservationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Reservation;
import model.Room;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ModifyReservationView {

    private final ReservationController reservationController;

    public ModifyReservationView(
            ReservationController reservationController
    ) {
        this.reservationController =
                reservationController;
    }

    public void show(
            Stage stage,
            Reservation existingReservation
    ) {

        Label title =
                new Label(
                        "Modify Reservation"
                );

        title.setStyle(
                Theme.TITLE
        );

        Label roomTitleLabel =
                new Label(
                        "Space:"
                );

        roomTitleLabel.setStyle(
                Theme.BOLD_LABEL
        );

        Label roomLabel =
                new Label(
                        getRoomName(
                                existingReservation
                                        .getRoomId()
                        )
                );

        roomLabel.setStyle(
                "-fx-font-size: 20px;" +
                        "-fx-text-fill: white;"
        );

        VBox roomSection =
                new VBox(
                        8,
                        roomTitleLabel,
                        roomLabel
                );

        roomSection.setAlignment(
                Pos.CENTER
        );

        Label dateLabel =
                new Label(
                        "Date:"
                );

        dateLabel.setStyle(
                Theme.BOLD_LABEL
        );

        DatePicker datePicker =
                new DatePicker(
                        existingReservation
                                .getDate()
                );

        datePicker.setPrefSize(
                300,
                45
        );

        datePicker.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        VBox dateSection =
                new VBox(
                        8,
                        dateLabel,
                        datePicker
                );

        dateSection.setAlignment(
                Pos.CENTER
        );

        Label startLabel =
                new Label(
                        "Start Time:"
                );

        startLabel.setStyle(
                Theme.BOLD_LABEL
        );

        ComboBox<String> startTimeBox =
                new ComboBox<>();

        startTimeBox.setPrefSize(
                300,
                45
        );

        startTimeBox.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        Label endLabel =
                new Label(
                        "End Time:"
                );

        endLabel.setStyle(
                Theme.BOLD_LABEL
        );

        ComboBox<String> endTimeBox =
                new ComboBox<>();

        endTimeBox.setPrefSize(
                300,
                45
        );

        endTimeBox.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        String[] times = {
                "8:00 AM",
                "9:00 AM",
                "10:00 AM",
                "11:00 AM",
                "12:00 PM",
                "1:00 PM",
                "2:00 PM",
                "3:00 PM",
                "4:00 PM",
                "5:00 PM"
        };

        startTimeBox
                .getItems()
                .addAll(times);

        endTimeBox
                .getItems()
                .addAll(times);

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern(
                        "h:mm a"
                );

        startTimeBox.setValue(
                existingReservation
                        .getStartTime()
                        .format(
                                formatter
                        )
        );

        endTimeBox.setValue(
                existingReservation
                        .getEndTime()
                        .format(
                                formatter
                        )
        );

        VBox startSection =
                new VBox(
                        8,
                        startLabel,
                        startTimeBox
                );

        startSection.setAlignment(
                Pos.CENTER
        );

        VBox endSection =
                new VBox(
                        8,
                        endLabel,
                        endTimeBox
                );

        endSection.setAlignment(
                Pos.CENTER
        );

        Label purposeLabel =
                new Label(
                        "Purpose / Description:"
                );

        purposeLabel.setStyle(
                Theme.BOLD_LABEL
        );

        TextArea purposeArea =
                new TextArea(
                        existingReservation
                                .getPurpose()
                );

        purposeArea.setPrefSize(
                300,
                90
        );

        purposeArea.setWrapText(
                true
        );

        purposeArea.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        VBox purposeSection =
                new VBox(
                        8,
                        purposeLabel,
                        purposeArea
                );

        purposeSection.setAlignment(
                Pos.CENTER
        );

        VBox form =
                new VBox(
                        20,
                        roomSection,
                        dateSection,
                        startSection,
                        endSection,
                        purposeSection
                );

        form.setAlignment(
                Pos.CENTER
        );

        form.setPadding(
                new Insets(30)
        );

        form.setMaxWidth(
                420
        );

        form.setStyle(
                "-fx-background-color: rgba(255,255,255,0.08);" +
                        "-fx-background-insets: 4;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: " + Theme.RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 18px;" +
                        "-fx-border-insets: 0;"
        );

        Button saveButton =
                new Button(
                        "Save Changes"
                );

        Button backButton =
                new Button(
                        "Back to My Reservations"
                );

        saveButton.setPrefSize(
                300,
                55
        );

        backButton.setPrefSize(
                300,
                55
        );

        Theme.styleModifyButton(
                saveButton
        );

        Theme.styleBackButton(
                backButton
        );

        saveButton.setOnAction(e -> {

            if (datePicker.getValue() == null) {

                showError(
                        "Missing Date",
                        "Please select a date."
                );

                return;
            }

            if (
                    datePicker
                            .getValue()
                            .isBefore(
                                    LocalDate.now()
                            )
            ) {

                showError(
                        "Invalid Date",
                        "A reservation cannot be changed to a past date."
                );

                return;
            }

            if (startTimeBox.getValue() == null) {

                showError(
                        "Missing Start Time",
                        "Please select a start time."
                );

                return;
            }

            if (endTimeBox.getValue() == null) {

                showError(
                        "Missing End Time",
                        "Please select an end time."
                );

                return;
            }

            if (
                    purposeArea
                            .getText()
                            .trim()
                            .isEmpty()
            ) {

                showError(
                        "Missing Purpose",
                        "Please enter a purpose or description."
                );

                return;
            }

            LocalTime newStartTime =
                    LocalTime.parse(
                            startTimeBox.getValue(),
                            formatter
                    );

            LocalTime newEndTime =
                    LocalTime.parse(
                            endTimeBox.getValue(),
                            formatter
                    );

            if (
                    !newEndTime.isAfter(
                            newStartTime
                    )
            ) {

                showError(
                        "Invalid Time",
                        "End time must be after the start time."
                );

                return;
            }

            if (
                    datePicker
                            .getValue()
                            .equals(
                                    LocalDate.now()
                            )
                            &&
                            newStartTime.isBefore(
                                    LocalTime.now()
                            )
            ) {

                showError(
                        "Invalid Time",
                        "A reservation cannot be changed to a time that has already passed."
                );

                return;
            }

            Reservation updatedReservation =
                    new Reservation(
                            datePicker.getValue(),
                            newStartTime,
                            newEndTime,
                            existingReservation
                                    .getRoomId(),
                            existingReservation
                                    .getUserId(),
                            purposeArea
                                    .getText()
                                    .trim()
                    );

            updatedReservation
                    .setCreationTimestamp(
                            existingReservation
                                    .getCreationTimestamp()
                    );

            boolean modified =
                    reservationController
                            .modifyReservation(
                                    existingReservation,
                                    updatedReservation
                            );

            if (modified) {

                Alert success =
                        new Alert(
                                Alert.AlertType.INFORMATION
                        );

                success.setTitle(
                        "Reservation Updated"
                );

                success.setHeaderText(
                        null
                );

                success.setContentText(
                        "The reservation was updated successfully."
                );

                success.showAndWait();

                new ViewMyReservationsView(
                        reservationController
                ).show(stage);

            } else {

                showError(
                        "Unable to Modify Reservation",
                        "The selected time may conflict with another reservation."
                );
            }
        });

        backButton.setOnAction(e ->

                new ViewMyReservationsView(
                        reservationController
                ).show(stage)
        );

        HBox buttons =
                new HBox(
                        20,
                        saveButton,
                        backButton
                );

        buttons.setAlignment(
                Pos.CENTER
        );

        VBox layout =
                new VBox(
                        30,
                        title,
                        form,
                        buttons
                );

        layout.setAlignment(
                Pos.CENTER
        );

        layout.setPadding(
                new Insets(40)
        );

        layout.setStyle(
                Theme.BACKGROUND
        );

        Scene scene =
                new Scene(
                        layout,
                        1500,
                        1000
                );

        stage.setTitle(
                "Modify Reservation"
        );

        stage.setScene(scene);
        stage.show();
    }

    private String getRoomName(
            String roomId
    ) {

        List<Room> rooms =
                reservationController
                        .getAllRooms();

        for (Room room : rooms) {

            if (
                    room.getRoomNumber()
                            .equals(roomId)
            ) {

                return room.getName();
            }
        }

        return "Room " + roomId;
    }

    private void showError(
            String title,
            String message
    ) {

        Alert alert =
                new Alert(
                        Alert.AlertType.ERROR
                );

        alert.setTitle(
                title
        );

        alert.setHeaderText(
                null
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }
}