package view;

import controller.ReservationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainView {

    private final ReservationController reservationController;

    public MainView(
            ReservationController reservationController
    ) {
        this.reservationController = reservationController;
    }

    public void show(Stage stage) {

        Label title =
                new Label(
                        "Valdosta State Space Reservation"
                );

        title.setStyle(
                "-fx-font-size: 52px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: white;"
        );

        Label description =
                new Label(
                        "Find and reserve campus spaces"
                );

        description.setStyle(
                "-fx-font-size: 20px;" +
                        "-fx-text-fill: #D6D6D6;"
        );

        Button createButton =
                new Button(
                        "Create Reservation"
                );

        Button spacesButton =
                new Button(
                        "View Spaces"
                );

        Button reservationsButton =
                new Button(
                        "View My Reservations"
                );

        createButton.setPrefSize(520, 65);
        spacesButton.setPrefSize(520, 65);
        reservationsButton.setPrefSize(520, 65);

        addHoverEffect(
                createButton,
                "#F5F5F5",
                "#1A1A1A",
                "#C32032",
                "white"
        );

        addHoverEffect(
                spacesButton,
                "#F5F5F5",
                "#1A1A1A",
                "#C32032",
                "white"
        );

        addHoverEffect(
                reservationsButton,
                "#F5F5F5",
                "#1A1A1A",
                "#C32032",
                "white"
        );

        createButton.setOnAction(e -> {

            CreateReservationView createView =
                    new CreateReservationView(
                            reservationController
                    );

            createView.show(stage);
        });

        spacesButton.setOnAction(e -> {

            ViewSpacesView spacesView =
                    new ViewSpacesView(
                            reservationController
                    );

            spacesView.show(stage);
        });

        reservationsButton.setOnAction(e -> {

            ViewMyReservationsView reservationsView =
                    new ViewMyReservationsView(
                            reservationController
                    );

            reservationsView.show(stage);
        });

        VBox menuCard =
                new VBox(
                        20,
                        createButton,
                        spacesButton,
                        reservationsButton
                );

        menuCard.setAlignment(
                Pos.CENTER
        );

        menuCard.setPadding(
                new Insets(40)
        );

        menuCard.setMaxWidth(
                620
        );

        menuCard.setStyle(
                "-fx-background-color: rgba(255,255,255,0.08);" +
                        "-fx-background-radius: 18px;" +
                        "-fx-border-color: #C32032;" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 18px;"
        );

        VBox layout =
                new VBox(
                        12,
                        title,
                        description,
                        menuCard
                );

        layout.setAlignment(
                Pos.CENTER
        );

        layout.setPadding(
                new Insets(50)
        );

        VBox.setMargin(
                menuCard,
                new Insets(
                        30,
                        0,
                        0,
                        0
                )
        );

        layout.setStyle(
                Theme.BACKGROUND
        );

        Scene scene =
                new Scene(
                        layout,
                        1500,
                        1000
                );

        stage.setTitle(
                "Valdosta State Space Reservation"
        );

        stage.setScene(scene);
        stage.show();
    }

    private void addHoverEffect(
            Button button,
            String normalBackground,
            String normalText,
            String hoverBackground,
            String hoverText
    ) {

        String normalStyle =
                "-fx-font-size: 22px;" +
                        "-fx-background-color: " + normalBackground + ";" +
                        "-fx-text-fill: " + normalText + ";" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-border-color: transparent;" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 10px;" +
                        "-fx-background-insets: 0;" +
                        "-fx-border-insets: 0;" +
                        "-fx-cursor: hand;";

        String hoverStyle =
                "-fx-font-size: 22px;" +
                        "-fx-background-color: " + hoverBackground + ";" +
                        "-fx-text-fill: " + hoverText + ";" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-border-color: #8A1422;" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 10px;" +
                        "-fx-background-insets: 0;" +
                        "-fx-border-insets: 0;" +
                        "-fx-cursor: hand;";

        button.setStyle(
                normalStyle
        );

        button.setOnMouseEntered(e ->
                button.setStyle(
                        hoverStyle
                )
        );

        button.setOnMouseExited(e ->
                button.setStyle(
                        normalStyle
                )
        );
    }
}