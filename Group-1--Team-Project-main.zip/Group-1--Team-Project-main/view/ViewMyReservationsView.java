package view;

import controller.ReservationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Reservation;
import model.Room;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class ViewMyReservationsView {

    private static final String CURRENT_USER_ID =
            "student";

    private final ReservationController reservationController;

    public ViewMyReservationsView(
            ReservationController reservationController
    ) {
        this.reservationController =
                reservationController;
    }

    public void show(Stage stage) {

        Label title =
                new Label(
                        "My Reservations"
                );

        title.setStyle(
                Theme.TITLE
        );

        VBox reservationsContainer =
                new VBox(
                        20
                );

        reservationsContainer.setAlignment(
                Pos.CENTER
        );

        List<Reservation> reservations =
                reservationController
                        .getReservationsForUser(
                                CURRENT_USER_ID
                        );

        if (reservations.isEmpty()) {

            Label emptyLabel =
                    new Label(
                            "You currently have no reservations."
                    );

            emptyLabel.setStyle(
                    Theme.BOLD_LABEL
            );

            reservationsContainer
                    .getChildren()
                    .add(
                            emptyLabel
                    );

        } else {

            for (
                    Reservation reservation :
                    reservations
            ) {

                reservationsContainer
                        .getChildren()
                        .add(
                                createReservationCard(
                                        stage,
                                        reservation
                                )
                        );
            }
        }

        ScrollPane scrollPane =
                new ScrollPane(
                        reservationsContainer
                );

        scrollPane.setFitToWidth(
                true
        );

        scrollPane.setPrefHeight(
                650
        );

        scrollPane.setStyle(
                "-fx-background: transparent;" +
                        "-fx-background-color: transparent;"
        );

        Button backButton =
                new Button(
                        "Back to Main Menu"
                );

        backButton.setPrefSize(
                300,
                55
        );

        Theme.styleBackButton(
                backButton
        );

        backButton.setOnAction(e ->

                new MainView(
                        reservationController
                ).show(stage)
        );

        VBox layout =
                new VBox(
                        30,
                        title,
                        scrollPane,
                        backButton
                );

        layout.setAlignment(
                Pos.CENTER
        );

        layout.setPadding(
                new Insets(40)
        );

        layout.setStyle(
                Theme.BACKGROUND
        );

        Scene scene =
                new Scene(
                        layout,
                        1500,
                        1000
                );

        stage.setTitle(
                "My Reservations"
        );

        stage.setScene(scene);
        stage.show();
    }

    private VBox createReservationCard(
            Stage stage,
            Reservation reservation
    ) {

        DateTimeFormatter dateFormatter =
                DateTimeFormatter.ofPattern(
                        "MMMM d, yyyy"
                );

        DateTimeFormatter timeFormatter =
                DateTimeFormatter.ofPattern(
                        "h:mm a"
                );

        String roomName =
                getRoomName(
                        reservation
                                .getRoomId()
                );

        Label roomLabel =
                new Label(
                        roomName
                );

        roomLabel.setStyle(
                Theme.CARD_TITLE
        );

        Label dateLabel =
                new Label(
                        "Date: " +
                                reservation
                                        .getDate()
                                        .format(
                                                dateFormatter
                                        )
                );

        dateLabel.setStyle(
                Theme.CARD_TEXT
        );

        Label timeLabel =
                new Label(
                        "Time: " +
                                reservation
                                        .getStartTime()
                                        .format(
                                                timeFormatter
                                        )
                                +
                                " - "
                                +
                                reservation
                                        .getEndTime()
                                        .format(
                                                timeFormatter
                                        )
                );

        timeLabel.setStyle(
                Theme.CARD_TEXT
        );

        Label purposeLabel =
                new Label(
                        "Purpose: " +
                                reservation
                                        .getPurpose()
                );

        purposeLabel.setStyle(
                Theme.CARD_TEXT
        );

        purposeLabel.setWrapText(
                true
        );

        Button modifyButton =
                new Button(
                        "Modify"
                );

        Button cancelButton =
                new Button(
                        "Cancel"
                );

        modifyButton.setPrefSize(
                160,
                45
        );

        cancelButton.setPrefSize(
                160,
                45
        );

        Theme.styleModifyButton(
                modifyButton
        );

        Theme.styleCancelButton(
                cancelButton
        );

        modifyButton.setOnAction(e ->

                new ModifyReservationView(
                        reservationController
                ).show(
                        stage,
                        reservation
                )
        );

        cancelButton.setOnAction(e -> {

            Alert confirmation =
                    new Alert(
                            Alert.AlertType.CONFIRMATION
                    );

            confirmation.setTitle(
                    "Cancel Reservation"
            );

            confirmation.setHeaderText(
                    null
            );

            confirmation.setContentText(
                    "Are you sure you want to cancel this reservation?"
            );

            Optional<ButtonType> result =
                    confirmation.showAndWait();

            if (
                    result.isPresent()
                            &&
                            result.get()
                                    == ButtonType.OK
            ) {

                boolean cancelled =
                        reservationController
                                .cancelReservation(
                                        reservation
                                );

                if (cancelled) {

                    Alert success =
                            new Alert(
                                    Alert.AlertType.INFORMATION
                            );

                    success.setTitle(
                            "Reservation Cancelled"
                    );

                    success.setHeaderText(
                            null
                    );

                    success.setContentText(
                            "The reservation was cancelled successfully."
                    );

                    success.showAndWait();

                    show(stage);

                } else {

                    showError(
                            "Unable to Cancel",
                            "The reservation could not be cancelled."
                    );
                }
            }
        });

        HBox buttons =
                new HBox(
                        15,
                        modifyButton,
                        cancelButton
                );

        buttons.setAlignment(
                Pos.CENTER
        );

        VBox card =
                new VBox(
                        12,
                        roomLabel,
                        dateLabel,
                        timeLabel,
                        purposeLabel,
                        buttons
                );

        card.setAlignment(
                Pos.CENTER
        );

        card.setPadding(
                new Insets(25)
        );

        card.setMaxWidth(
                700
        );

        card.setStyle(
                "-fx-background-color: white;" +
                        "-fx-background-insets: 4;" +
                        "-fx-background-radius: 8px;" +
                        "-fx-border-color: " + Theme.RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 12px;" +
                        "-fx-border-insets: 0;"
        );

        return card;
    }

    private String getRoomName(
            String roomId
    ) {

        List<Room> rooms =
                reservationController
                        .getAllRooms();

        for (Room room : rooms) {

            if (
                    room.getRoomNumber()
                            .equals(roomId)
            ) {

                return room.getName();
            }
        }

        return "Room " + roomId;
    }

    private void showError(
            String title,
            String message
    ) {

        Alert alert =
                new Alert(
                        Alert.AlertType.ERROR
                );

        alert.setTitle(
                title
        );

        alert.setHeaderText(
                null
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }
}