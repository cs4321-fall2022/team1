package view;

import controller.ReservationController;
import javafx.application.Application;
import javafx.stage.Stage;
import model.ReservationManager;
import model.Room;
import model.RoomManager;

import java.util.Arrays;

public class Main extends Application {

    @Override
    public void start(Stage stage) {

        ReservationManager reservationManager =
                new ReservationManager();

        RoomManager roomManager =
                new RoomManager();

        roomManager.addRoom(
                new Room(
                        "101",
                        "Room 101",
                        "Main Hall",
                        25,
                        Arrays.asList(
                                "Projector",
                                "Whiteboard"
                        )
                )
        );

        roomManager.addRoom(
                new Room(
                        "205",
                        "Room 205",
                        "Science Building",
                        40,
                        Arrays.asList(
                                "Projector",
                                "Computers",
                                "Smart Board"
                        )
                )
        );

        roomManager.addRoom(
                new Room(
                        "310",
                        "Room 310",
                        "Library",
                        12,
                        Arrays.asList(
                                "Whiteboard",
                                "TV",
                                "Study Tables"
                        )
                )
        );

        ReservationController reservationController =
                new ReservationController(
                        reservationManager,
                        roomManager
                );

        MainView mainView =
                new MainView(
                        reservationController
                );

        mainView.show(stage);
    }

    public static void main(
            String[] args
    ) {
        launch(args);
    }
}