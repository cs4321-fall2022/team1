package view;

import javafx.scene.control.Button;

public class Theme {

    public static final String RED = "#C32032";
    public static final String DARK_RED = "#8A1422";
    public static final String BLACK = "#111111";
    public static final String DARK_GRAY = "#292929";
    public static final String GRAY = "#555555";
    public static final String LIGHT = "#F5F5F5";
    public static final String WHITE = "white";
    public static final String GOLD = "#F4C542";

    public static final String BACKGROUND =
            "-fx-background-color: linear-gradient(to bottom, #111111, #292929);";

    public static final String TITLE =
            "-fx-font-size: 46px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: white;";

    public static final String LABEL =
            "-fx-font-size: 20px;" +
                    "-fx-text-fill: white;";

    public static final String BOLD_LABEL =
            "-fx-font-size: 20px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: white;";

    public static final String CARD_TEXT =
            "-fx-font-size: 18px;" +
                    "-fx-text-fill: black;";

    public static final String CARD_TITLE =
            "-fx-font-size: 24px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: black;";

    public static void styleButton(
            Button button,
            String normalBackground,
            String normalText,
            String hoverBackground,
            String hoverText
    ) {

        String normalStyle =
                "-fx-font-size: 18px;" +
                        "-fx-background-color: " + normalBackground + ";" +
                        "-fx-text-fill: " + normalText + ";" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-border-color: transparent;" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 10px;" +
                        "-fx-background-insets: 0;" +
                        "-fx-border-insets: 0;" +
                        "-fx-cursor: hand;";

        String hoverStyle =
                "-fx-font-size: 18px;" +
                        "-fx-background-color: " + hoverBackground + ";" +
                        "-fx-text-fill: " + hoverText + ";" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-border-color: " + DARK_RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 10px;" +
                        "-fx-background-insets: 0;" +
                        "-fx-border-insets: 0;" +
                        "-fx-cursor: hand;";

        button.setStyle(normalStyle);

        button.setOnMouseEntered(e ->
                button.setStyle(hoverStyle)
        );

        button.setOnMouseExited(e ->
                button.setStyle(normalStyle)
        );
    }

    public static void stylePrimaryButton(Button button) {
        styleButton(
                button,
                LIGHT,
                BLACK,
                RED,
                WHITE
        );
    }

    public static void styleBackButton(Button button) {
        styleButton(
                button,
                GRAY,
                WHITE,
                RED,
                WHITE
        );
    }

    public static void styleCancelButton(Button button) {
        styleButton(
                button,
                RED,
                WHITE,
                DARK_RED,
                WHITE
        );
    }

    public static void styleModifyButton(Button button) {
        styleButton(
                button,
                GOLD,
                BLACK,
                RED,
                WHITE
        );
    }
}