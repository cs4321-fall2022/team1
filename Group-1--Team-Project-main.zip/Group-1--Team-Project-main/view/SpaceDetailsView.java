package view;

import controller.ReservationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import model.Reservation;
import model.Room;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class SpaceDetailsView {

    private final ReservationController reservationController;

    public SpaceDetailsView(
            ReservationController reservationController
    ) {
        this.reservationController =
                reservationController;
    }

    public void show(
            Stage stage,
            Room room
    ) {

        Label title =
                new Label(
                        room.getName()
                );

        title.setStyle(
                Theme.TITLE
        );

        Label roomNumberLabel =
                new Label(
                        "Room: " +
                                room.getRoomNumber()
                );

        Label buildingLabel =
                new Label(
                        "Building: " +
                                room.getBuilding()
                );

        Label capacityLabel =
                new Label(
                        "Capacity: " +
                                room.getCapacity()
                );

        Label featuresLabel =
                new Label(
                        "Features: " +
                                String.join(
                                        ", ",
                                        room.getFeatures()
                                )
                );

        String informationStyle =
                "-fx-font-size: 22px;" +
                        "-fx-text-fill: white;";

        roomNumberLabel.setStyle(
                informationStyle
        );

        buildingLabel.setStyle(
                informationStyle
        );

        capacityLabel.setStyle(
                informationStyle
        );

        featuresLabel.setStyle(
                informationStyle
        );

        featuresLabel.setWrapText(
                true
        );

        featuresLabel.setMaxWidth(
                600
        );

        featuresLabel.setAlignment(
                Pos.CENTER
        );

        featuresLabel.setTextAlignment(
                TextAlignment.CENTER
        );

        VBox roomInfo =
                new VBox(
                        18,
                        roomNumberLabel,
                        buildingLabel,
                        capacityLabel,
                        featuresLabel
                );

        roomInfo.setAlignment(
                Pos.CENTER
        );

        roomInfo.setPadding(
                new Insets(30)
        );

        roomInfo.setMaxWidth(
                650
        );

        roomInfo.setStyle(
                "-fx-background-color: rgba(255,255,255,0.08);" +
                        "-fx-background-insets: 4;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: " + Theme.RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 18px;" +
                        "-fx-border-insets: 0;"
        );

        Label dateLabel =
                new Label(
                        "Select a Date:"
                );

        dateLabel.setStyle(
                Theme.BOLD_LABEL
        );

        DatePicker datePicker =
                new DatePicker();

        datePicker.setPrefSize(
                300,
                45
        );

        datePicker.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        VBox dateSection =
                new VBox(
                        10,
                        dateLabel,
                        datePicker
                );

        dateSection.setAlignment(
                Pos.CENTER
        );

        Button availabilityButton =
                new Button(
                        "View Availability"
                );

        availabilityButton.setPrefSize(
                300,
                55
        );

        Theme.stylePrimaryButton(
                availabilityButton
        );

        availabilityButton.setOnAction(e -> {

            LocalDate selectedDate =
                    datePicker.getValue();

            if (selectedDate == null) {

                showWarning(
                        "Select a Date",
                        "Please select a date before viewing availability."
                );

                return;
            }

            if (selectedDate
                    .isBefore(LocalDate.now())) {

                showWarning(
                        "Invalid Date",
                        "Please select today or a future date."
                );

                return;
            }

            List<Reservation> reservations =
                    reservationController
                            .getReservationsForRoomAndDate(
                                    room.getRoomNumber(),
                                    selectedDate
                            );

            DateTimeFormatter formatter =
                    DateTimeFormatter.ofPattern(
                            "h:mm a"
                    );

            StringBuilder reservedText =
                    new StringBuilder();

            if (reservations.isEmpty()) {

                reservedText.append(
                        "None"
                );

            } else {

                for (
                        Reservation reservation :
                        reservations
                ) {

                    reservedText
                            .append(
                                    reservation
                                            .getStartTime()
                                            .format(formatter)
                            )
                            .append(" - ")
                            .append(
                                    reservation
                                            .getEndTime()
                                            .format(formatter)
                            )
                            .append("\n");
                }
            }

            StringBuilder availableText =
                    new StringBuilder();

            LocalTime current =
                    LocalTime.of(
                            8,
                            0
                    );

            LocalTime closingTime =
                    LocalTime.of(
                            17,
                            0
                    );

            while (
                    current.isBefore(
                            closingTime
                    )
            ) {

                LocalTime slotStart =
                        current;

                LocalTime slotEnd =
                        current.plusHours(
                                1
                        );

                boolean reserved =
                        false;

                for (
                        Reservation reservation :
                        reservations
                ) {

                    if (
                            slotStart.isBefore(
                                    reservation
                                            .getEndTime()
                            )
                                    &&
                                    slotEnd.isAfter(
                                            reservation
                                                    .getStartTime()
                                    )
                    ) {

                        reserved = true;
                        break;
                    }
                }

                if (!reserved) {

                    availableText
                            .append(
                                    slotStart
                                            .format(formatter)
                            )
                            .append(" - ")
                            .append(
                                    slotEnd
                                            .format(formatter)
                            )
                            .append("\n");
                }

                current =
                        current.plusHours(
                                1
                        );
            }

            if (availableText.length() == 0) {

                availableText.append(
                        "No available times."
                );
            }

            Alert alert =
                    new Alert(
                            Alert.AlertType.INFORMATION
                    );

            alert.setTitle(
                    "Availability"
            );

            alert.setHeaderText(
                    room.getName() +
                            " - " +
                            selectedDate
            );

            alert.setContentText(
                    "Reserved Times:\n" +
                            reservedText +
                            "\nAvailable Times:\n" +
                            availableText
            );

            alert.showAndWait();
        });

        Button createReservationButton =
                new Button(
                        "Create Reservation"
                );

        createReservationButton.setPrefSize(
                300,
                55
        );

        Theme.styleButton(
                createReservationButton,
                Theme.RED,
                Theme.WHITE,
                Theme.DARK_RED,
                Theme.WHITE
        );

        createReservationButton.setOnAction(e ->

                new CreateReservationView(
                        reservationController
                ).show(
                        stage,
                        room,
                        datePicker.getValue()
                )
        );

        Button backButton =
                new Button(
                        "Back to View Spaces"
                );

        backButton.setPrefSize(
                300,
                55
        );

        Theme.styleBackButton(
                backButton
        );

        backButton.setOnAction(e ->

                new ViewSpacesView(
                        reservationController
                ).show(stage)
        );

        VBox buttons =
                new VBox(
                        15,
                        availabilityButton,
                        createReservationButton,
                        backButton
                );

        buttons.setAlignment(
                Pos.CENTER
        );

        VBox layout =
                new VBox(
                        30,
                        title,
                        roomInfo,
                        dateSection,
                        buttons
                );

        layout.setAlignment(
                Pos.CENTER
        );

        layout.setPadding(
                new Insets(40)
        );

        layout.setStyle(
                Theme.BACKGROUND
        );

        Scene scene =
                new Scene(
                        layout,
                        1500,
                        1000
                );

        stage.setTitle(
                room.getName()
        );

        stage.setScene(scene);
        stage.show();
    }

    private void showWarning(
            String title,
            String message
    ) {

        Alert alert =
                new Alert(
                        Alert.AlertType.WARNING
                );

        alert.setTitle(
                title
        );

        alert.setHeaderText(
                null
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }
}