package view;

import controller.ReservationController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import model.Room;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CreateReservationView {

    private static final String CURRENT_USER_ID =
            "student";

    private final ReservationController reservationController;

    public CreateReservationView(
            ReservationController reservationController
    ) {
        this.reservationController =
                reservationController;
    }

    public void show(Stage stage) {
        show(
                stage,
                null,
                null
        );
    }

    public void show(
            Stage stage,
            Room selectedRoom,
            LocalDate selectedDate
    ) {

        boolean cameFromRoomDetails =
                selectedRoom != null;

        Label title =
                new Label(
                        "Create Reservation"
                );

        title.setStyle(
                Theme.TITLE
        );

        Label roomLabel =
                new Label(
                        "Space:"
                );

        roomLabel.setStyle(
                Theme.BOLD_LABEL
        );

        ComboBox<Room> roomBox =
                new ComboBox<>();

        roomBox
                .getItems()
                .addAll(
                        reservationController
                                .getAllRooms()
                );

        roomBox.setPromptText(
                "Select a space"
        );

        roomBox.setPrefSize(
                300,
                45
        );

        roomBox.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        roomBox.setConverter(
                new StringConverter<Room>() {

                    @Override
                    public String toString(Room room) {

                        if (room == null) {
                            return "";
                        }

                        return room.getName();
                    }

                    @Override
                    public Room fromString(
                            String string
                    ) {
                        return null;
                    }
                }
        );

        if (selectedRoom != null) {
            roomBox.setValue(
                    selectedRoom
            );
        }

        VBox roomSection =
                new VBox(
                        8,
                        roomLabel,
                        roomBox
                );

        roomSection.setAlignment(
                Pos.CENTER
        );

        Label dateLabel =
                new Label(
                        "Date:"
                );

        dateLabel.setStyle(
                Theme.BOLD_LABEL
        );

        DatePicker datePicker =
                new DatePicker();

        datePicker.setPrefSize(
                300,
                45
        );

        datePicker.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        if (selectedDate != null) {
            datePicker.setValue(
                    selectedDate
            );
        }

        VBox dateSection =
                new VBox(
                        8,
                        dateLabel,
                        datePicker
                );

        dateSection.setAlignment(
                Pos.CENTER
        );

        Label startLabel =
                new Label(
                        "Start Time:"
                );

        startLabel.setStyle(
                Theme.BOLD_LABEL
        );

        ComboBox<String> startTimeBox =
                new ComboBox<>();

        startTimeBox.setPromptText(
                "Select start time"
        );

        startTimeBox.setPrefSize(
                300,
                45
        );

        startTimeBox.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        VBox startSection =
                new VBox(
                        8,
                        startLabel,
                        startTimeBox
                );

        startSection.setAlignment(
                Pos.CENTER
        );

        Label endLabel =
                new Label(
                        "End Time:"
                );

        endLabel.setStyle(
                Theme.BOLD_LABEL
        );

        ComboBox<String> endTimeBox =
                new ComboBox<>();

        endTimeBox.setPromptText(
                "Select end time"
        );

        endTimeBox.setPrefSize(
                300,
                45
        );

        endTimeBox.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        VBox endSection =
                new VBox(
                        8,
                        endLabel,
                        endTimeBox
                );

        endSection.setAlignment(
                Pos.CENTER
        );

        String[] times = {
                "8:00 AM",
                "9:00 AM",
                "10:00 AM",
                "11:00 AM",
                "12:00 PM",
                "1:00 PM",
                "2:00 PM",
                "3:00 PM",
                "4:00 PM",
                "5:00 PM"
        };

        startTimeBox
                .getItems()
                .addAll(times);

        endTimeBox
                .getItems()
                .addAll(times);

        Label purposeLabel =
                new Label(
                        "Purpose / Description:"
                );

        purposeLabel.setStyle(
                Theme.BOLD_LABEL
        );

        TextArea purposeArea =
                new TextArea();

        purposeArea.setPromptText(
                "Enter the purpose of the reservation"
        );

        purposeArea.setPrefSize(
                300,
                90
        );

        purposeArea.setWrapText(
                true
        );

        purposeArea.setStyle(
                "-fx-font-size: 18px;" +
                        "-fx-background-radius: 8px;"
        );

        VBox purposeSection =
                new VBox(
                        8,
                        purposeLabel,
                        purposeArea
                );

        purposeSection.setAlignment(
                Pos.CENTER
        );

        VBox form =
                new VBox(
                        20,
                        roomSection,
                        dateSection,
                        startSection,
                        endSection,
                        purposeSection
                );

        form.setAlignment(
                Pos.CENTER
        );

        form.setPadding(
                new Insets(30)
        );

        form.setMaxWidth(
                420
        );

        form.setStyle(
                "-fx-background-color: rgba(255,255,255,0.08);" +
                        "-fx-background-radius: 18px;" +
                        "-fx-border-color: " + Theme.RED + ";" +
                        "-fx-border-width: 4px;" +
                        "-fx-border-radius: 18px;"
        );

        Button createButton =
                new Button(
                        "Create Reservation"
                );

        Button backButton;

        if (cameFromRoomDetails) {

            backButton =
                    new Button(
                            "Back to Room Details"
                    );

        } else {

            backButton =
                    new Button(
                            "Back to Main Menu"
                    );
        }

        createButton.setPrefSize(
                300,
                55
        );

        backButton.setPrefSize(
                300,
                55
        );

        Theme.stylePrimaryButton(
                createButton
        );

        Theme.styleBackButton(
                backButton
        );

        createButton.setOnAction(e -> {

            Room room =
                    roomBox.getValue();

            if (room == null) {

                showError(
                        "Missing Space",
                        "Please select a space."
                );

                return;
            }

            if (datePicker.getValue() == null) {

                showError(
                        "Missing Date",
                        "Please select a date."
                );

                return;
            }

            if (datePicker
                    .getValue()
                    .isBefore(LocalDate.now())) {

                showError(
                        "Invalid Date",
                        "Reservations cannot be created for a past date."
                );

                return;
            }

            if (startTimeBox.getValue() == null) {

                showError(
                        "Missing Start Time",
                        "Please select a start time."
                );

                return;
            }

            if (endTimeBox.getValue() == null) {

                showError(
                        "Missing End Time",
                        "Please select an end time."
                );

                return;
            }

            if (purposeArea
                    .getText()
                    .trim()
                    .isEmpty()) {

                showError(
                        "Missing Purpose",
                        "Please enter a purpose or description."
                );

                return;
            }

            DateTimeFormatter formatter =
                    DateTimeFormatter.ofPattern(
                            "h:mm a"
                    );

            LocalTime startTime =
                    LocalTime.parse(
                            startTimeBox.getValue(),
                            formatter
                    );

            LocalTime endTime =
                    LocalTime.parse(
                            endTimeBox.getValue(),
                            formatter
                    );

            if (!endTime.isAfter(startTime)) {

                showError(
                        "Invalid Time",
                        "End time must be after the start time."
                );

                return;
            }

            if (datePicker
                    .getValue()
                    .equals(LocalDate.now())
                    &&
                    startTime.isBefore(
                            LocalTime.now()
                    )) {

                showError(
                        "Invalid Time",
                        "Reservations cannot be created for a time that has already passed."
                );

                return;
            }

            boolean created =
                    reservationController
                            .createReservation(
                                    datePicker.getValue(),
                                    startTime,
                                    endTime,
                                    room.getRoomNumber(),
                                    CURRENT_USER_ID,
                                    purposeArea
                                            .getText()
                                            .trim()
                            );

            if (created) {

                Alert success =
                        new Alert(
                                Alert.AlertType.INFORMATION
                        );

                success.setTitle(
                        "Reservation Created"
                );

                success.setHeaderText(
                        null
                );

                success.setContentText(
                        "Your reservation was created successfully."
                );

                success.showAndWait();

                new ViewMyReservationsView(
                        reservationController
                ).show(stage);

            } else {

                showError(
                        "Unable to Create Reservation",
                        "The reservation could not be created. The selected time may already be reserved or the reservation may be invalid."
                );
            }
        });

        backButton.setOnAction(e -> {

            if (cameFromRoomDetails) {

                new SpaceDetailsView(
                        reservationController
                ).show(
                        stage,
                        selectedRoom
                );

            } else {

                new MainView(
                        reservationController
                ).show(stage);
            }
        });

        HBox buttons =
                new HBox(
                        20,
                        createButton,
                        backButton
                );

        buttons.setAlignment(
                Pos.CENTER
        );

        VBox layout =
                new VBox(
                        30,
                        title,
                        form,
                        buttons
                );

        layout.setAlignment(
                Pos.CENTER
        );

        layout.setPadding(
                new Insets(40)
        );

        layout.setStyle(
                Theme.BACKGROUND
        );

        Scene scene =
                new Scene(
                        layout,
                        1500,
                        1000
                );

        stage.setTitle(
                "Create Reservation"
        );

        stage.setScene(scene);
        stage.show();
    }

    private void showError(
            String title,
            String message
    ) {

        Alert alert =
                new Alert(
                        Alert.AlertType.ERROR
                );

        alert.setTitle(
                title
        );

        alert.setHeaderText(
                null
        );

        alert.setContentText(
                message
        );

        alert.showAndWait();
    }
}