package test;

import model.Reservation;
import model.ReservationManager;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Purpose: Tests the ReservationManager backend logic, including reservation
 * validation, scheduling conflicts, sorting, modification, and cancellation.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class ReservationManagerTest {

    @Test
    public void testAddValidReservation() {
        ReservationManager manager = new ReservationManager();

        Reservation reservation = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        assertTrue(manager.addReservation(reservation));
        assertEquals(1, manager.getReservations().size());
    }

    @Test
    public void testOverlappingReservationRejected() {
        ReservationManager manager = new ReservationManager();

        Reservation first = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        Reservation overlapping = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 30),
                LocalTime.of(11, 30),
                "101",
                "student2"
        );

        assertTrue(manager.addReservation(first));
        assertFalse(manager.addReservation(overlapping));
    }

    @Test
    public void testBackToBackReservationAccepted() {
        ReservationManager manager = new ReservationManager();

        Reservation first = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        Reservation second = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(11, 0),
                LocalTime.of(12, 0),
                "101",
                "student2"
        );

        assertTrue(manager.addReservation(first));
        assertTrue(manager.addReservation(second));
    }

    @Test
    public void testInvalidTimeRangeRejected() {
        ReservationManager manager = new ReservationManager();

        Reservation reservation = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(12, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        assertFalse(manager.addReservation(reservation));
    }

    @Test
    public void testPastReservationRejected() {
        ReservationManager manager = new ReservationManager();

        Reservation reservation = new Reservation(
                LocalDate.now().minusDays(1),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        assertFalse(manager.addReservation(reservation));
    }

    @Test
    public void testMissingInformationRejected() {
        ReservationManager manager = new ReservationManager();

        Reservation reservation = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                null,
                "student1"
        );

        assertFalse(manager.addReservation(reservation));
    }

    @Test
    public void testReservationsSortedByStartTime() {
        ReservationManager manager = new ReservationManager();

        Reservation later = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(14, 0),
                LocalTime.of(15, 0),
                "101",
                "student1"
        );

        Reservation earlier = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(9, 0),
                LocalTime.of(10, 0),
                "101",
                "student2"
        );

        manager.addReservation(later);
        manager.addReservation(earlier);

        List<Reservation> reservations =
                manager.getReservationsForRoomAndDate(
                        "101",
                        LocalDate.now().plusDays(5)
                );

        assertEquals(LocalTime.of(9, 0),
                reservations.get(0).getStartTime());

        assertEquals(LocalTime.of(14, 0),
                reservations.get(1).getStartTime());
    }

    @Test
    public void testCancelReservation() {
        ReservationManager manager = new ReservationManager();

        Reservation reservation = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        manager.addReservation(reservation);

        assertTrue(manager.cancelReservation(reservation));
        assertEquals(0, manager.getReservations().size());
    }

    @Test
    public void testModifyReservation() {
        ReservationManager manager = new ReservationManager();

        Reservation original = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        manager.addReservation(original);

        Reservation updated = new Reservation(
                LocalDate.now().plusDays(5),
                LocalTime.of(13, 0),
                LocalTime.of(14, 0),
                "101",
                "student1"
        );

        assertTrue(manager.modifyReservation(original, updated));

        assertEquals(
                LocalTime.of(13, 0),
                manager.getReservations().get(0).getStartTime()
        );
    }
}