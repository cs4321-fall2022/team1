package test;

import model.Room;
import model.RoomManager;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
/**
 * Purpose: Tests the RoomManager backend logic, including adding rooms
 * and filtering rooms based on minimum capacity requirements.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class RoomManagerTest {

    @Test
    public void testAddRoom() {
        RoomManager manager = new RoomManager();

        Room room = new Room(
                "101",
                "Study Room 101",
                "Library",
                30,
                Arrays.asList("Projector", "Whiteboard")
        );

        manager.addRoom(room);

        assertEquals(1, manager.getAllRooms().size());
        assertEquals("101", manager.getAllRooms().get(0).getRoomNumber());
    }

    @Test
    public void testFilterByMinimumCapacity() {
        RoomManager manager = new RoomManager();

        Room smallRoom = new Room(
                "101",
                "Small Study Room",
                "Library",
                10,
                Arrays.asList("Whiteboard")
        );

        Room mediumRoom = new Room(
                "202",
                "Computer Lab",
                "Technology Center",
                30,
                Arrays.asList("Computers", "Projector")
        );

        Room largeRoom = new Room(
                "303",
                "Large Classroom",
                "Education Building",
                50,
                Arrays.asList("Projector", "Whiteboard")
        );

        manager.addRoom(smallRoom);
        manager.addRoom(mediumRoom);
        manager.addRoom(largeRoom);

        List<Room> results = manager.filterByMinimumCapacity(25);

        assertEquals(2, results.size());
        assertEquals("202", results.get(0).getRoomNumber());
        assertEquals("303", results.get(1).getRoomNumber());
    }

    @Test
    public void testCapacityEqualToMinimumIncluded() {
        RoomManager manager = new RoomManager();

        Room room = new Room(
                "101",
                "Study Room",
                "Library",
                30,
                Arrays.asList("Whiteboard")
        );

        manager.addRoom(room);

        List<Room> results = manager.filterByMinimumCapacity(30);

        assertEquals(1, results.size());
    }

    @Test
    public void testNoRoomsMeetMinimumCapacity() {
        RoomManager manager = new RoomManager();

        Room room = new Room(
                "101",
                "Study Room",
                "Library",
                20,
                Arrays.asList("Whiteboard")
        );

        manager.addRoom(room);

        List<Room> results = manager.filterByMinimumCapacity(50);

        assertEquals(0, results.size());
    }
}