package test;

import model.Reservation;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
/**
 * Purpose: Tests the Reservation model class to verify that reservation
 * data is created, stored, and updated correctly.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class ReservationTest {

    @Test
    public void testReservationCreation() {
        Reservation reservation = new Reservation(
                LocalDate.of(2026, 10, 8),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        assertEquals(LocalDate.of(2026, 10, 8), reservation.getDate());
        assertEquals(LocalTime.of(10, 0), reservation.getStartTime());
        assertEquals(LocalTime.of(11, 0), reservation.getEndTime());
        assertEquals("101", reservation.getRoomId());
        assertEquals("student1", reservation.getUserId());
    }

    @Test
    public void testReservationSetters() {
        Reservation reservation = new Reservation(
                LocalDate.of(2026, 10, 8),
                LocalTime.of(10, 0),
                LocalTime.of(11, 0),
                "101",
                "student1"
        );

        reservation.setDate(LocalDate.of(2026, 10, 9));
        reservation.setStartTime(LocalTime.of(2, 0));
        reservation.setEndTime(LocalTime.of(3, 0));
        reservation.setRoomId("202");
        reservation.setUserId("student2");

        assertEquals(LocalDate.of(2026, 10, 9), reservation.getDate());
        assertEquals(LocalTime.of(2, 0), reservation.getStartTime());
        assertEquals(LocalTime.of(3, 0), reservation.getEndTime());
        assertEquals("202", reservation.getRoomId());
        assertEquals("student2", reservation.getUserId());
    }
}
