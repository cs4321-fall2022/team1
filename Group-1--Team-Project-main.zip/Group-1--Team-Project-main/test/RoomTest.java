package test;

import model.Room;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
/**
 * Purpose: Tests the Room model class to verify that room
 * data is created, stored, and updated correctly.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class RoomTest {

    @Test
    public void testRoomCreation() {
        List<String> features =
                Arrays.asList("Projector", "Whiteboard", "Computers");

        Room room = new Room(
                "101",
                "Study Room 101",
                "Library",
                30,
                features
        );

        assertEquals("101", room.getRoomNumber());
        assertEquals("Study Room 101", room.getName());
        assertEquals("Library", room.getBuilding());
        assertEquals(30, room.getCapacity());
        assertEquals(features, room.getFeatures());
    }

    @Test
    public void testRoomSetters() {
        Room room = new Room(
                "101",
                "Study Room 101",
                "Library",
                30,
                Arrays.asList("Projector", "Whiteboard")
        );

        room.setRoomNumber("202");
        room.setName("Computer Lab");
        room.setBuilding("Technology Center");
        room.setCapacity(50);
        room.setFeatures(
                Arrays.asList("Computers", "Projector")
        );

        assertEquals("202", room.getRoomNumber());
        assertEquals("Computer Lab", room.getName());
        assertEquals("Technology Center", room.getBuilding());
        assertEquals(50, room.getCapacity());
        assertEquals(
                Arrays.asList("Computers", "Projector"),
                room.getFeatures()
        );
    }
}