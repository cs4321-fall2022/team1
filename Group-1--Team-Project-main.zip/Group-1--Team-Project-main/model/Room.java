package model;

import java.util.List;

/**
 * Purpose: Represents a campus room that can be reserved by users.
 * Stores the room number, name, building, capacity, and available features.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class Room {

    private String roomNumber;
    private String name;
    private String building;
    private int capacity;
    private List<String> features;

    public Room(String roomNumber, String name, String building,
                int capacity, List<String> features) {
        this.roomNumber = roomNumber;
        this.name = name;
        this.building = building;
        this.capacity = capacity;
        this.features = features;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public List<String> getFeatures() {
        return features;
    }

    public void setFeatures(List<String> features) {
        this.features = features;
    }
}