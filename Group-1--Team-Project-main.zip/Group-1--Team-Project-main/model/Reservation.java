package model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;

public class Reservation {

    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private String roomId;
    private String userId;
    private String purpose;
    private LocalDateTime creationTimestamp;

    public Reservation(LocalDate date, LocalTime startTime, LocalTime endTime,
                       String roomId, String userId) {

        this(date, startTime, endTime, roomId, userId, "");
    }

    public Reservation(LocalDate date, LocalTime startTime, LocalTime endTime,
                       String roomId, String userId, String purpose) {
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.roomId = roomId;
        this.userId = userId;
        this.purpose = purpose;
        this.creationTimestamp = LocalDateTime.now();
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPurpose() {
        return purpose;
    }
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public LocalDateTime getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(LocalDateTime creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

}