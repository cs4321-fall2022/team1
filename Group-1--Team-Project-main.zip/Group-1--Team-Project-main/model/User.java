package model;
/**
 * Purpose: Represents a user of the campus space reservation system.
 * Stores the user's username and assigned role.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class User {

    private String username;
    private String role;

    public User(String username, String role) {
        this.username = username;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}