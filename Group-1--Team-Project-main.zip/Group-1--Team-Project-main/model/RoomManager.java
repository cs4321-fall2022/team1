package model;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Purpose: Manages the collection of campus rooms and provides backend
 * functionality for adding rooms and filtering rooms by capacity.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */
public class RoomManager {

    private List<Room> rooms;

    public RoomManager() {
        rooms = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms);
    }

    public List<Room> filterByMinimumCapacity(int minimumCapacity) {
        return rooms.stream()
                .filter(room -> room.getCapacity() >= minimumCapacity)
                .collect(Collectors.toList());
    }
}
