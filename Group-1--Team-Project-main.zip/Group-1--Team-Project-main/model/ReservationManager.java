package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Purpose: Manages reservation data and the backend logic for creating,
 * modifying, canceling, validating, and retrieving reservations.
 * Also prevents scheduling conflicts and handles reservation sorting.
 *
 * Created by: Dana
 * Creation date: September 29, 2026
 */

public class ReservationManager {

    private List<Reservation> reservations;

    public ReservationManager() {
        reservations = new ArrayList<>();
    }

    public boolean isValidTimeRange(Reservation reservation) {
        if (reservation == null ||
                reservation.getDate() == null ||
                reservation.getStartTime() == null ||
                reservation.getEndTime() == null ||
                reservation.getRoomId() == null ||
                reservation.getUserId() == null) {
            return false;
        }

        return reservation.getEndTime()
                .isAfter(reservation.getStartTime());
    }

    public boolean isInPast(Reservation reservation) {
        LocalDateTime reservationStart = LocalDateTime.of(
                reservation.getDate(),
                reservation.getStartTime()
        );

        return reservationStart.isBefore(LocalDateTime.now());
    }

    public boolean hasConflict(Reservation newReservation) {

        for (Reservation existing : reservations) {

            if (existing.getRoomId().equals(newReservation.getRoomId())
                    && existing.getDate().equals(newReservation.getDate())) {

                boolean overlaps =
                        newReservation.getStartTime()
                                .isBefore(existing.getEndTime())
                                &&
                                newReservation.getEndTime()
                                        .isAfter(existing.getStartTime());

                if (overlaps) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean addReservation(Reservation reservation) {

        if (!isValidTimeRange(reservation)) {
            return false;
        }

        if (isInPast(reservation)) {
            return false;
        }

        if (hasConflict(reservation)) {
            return false;
        }

        reservations.add(reservation);
        return true;
    }

    public boolean cancelReservation(Reservation reservation) {
        return reservations.remove(reservation);
    }

    public boolean modifyReservation(
            Reservation existingReservation,
            Reservation updatedReservation) {

        if (!reservations.contains(existingReservation)) {
            return false;
        }

        if (!isValidTimeRange(updatedReservation)) {
            return false;
        }

        if (isInPast(updatedReservation)) {
            return false;
        }

        reservations.remove(existingReservation);

        if (hasConflict(updatedReservation)) {
            reservations.add(existingReservation);
            return false;
        }

        reservations.add(updatedReservation);
        return true;
    }

    public List<Reservation> getReservations() {
        return new ArrayList<>(reservations);
    }

    public List<Reservation> getReservationsForRoomAndDate(
            String roomId, LocalDate date) {

        return reservations.stream()
                .filter(r -> r.getRoomId().equals(roomId))
                .filter(r -> r.getDate().equals(date))
                .sorted(Comparator.comparing(Reservation::getStartTime))
                .collect(Collectors.toList());
    }

    public List<Reservation> getReservationsForUser(String userId) {

        return reservations.stream()
                .filter(r -> r.getUserId().equals(userId))
                .sorted(
                        Comparator.comparing(Reservation::getDate)
                                .thenComparing(Reservation::getStartTime)
                )
                .collect(Collectors.toList());
    }
}