# Group-1--Team-Project

# Campus Reservation System

## Overview
Team project for Software Engineering. This application is a JavaFX-based Campus Space Reservation System designed using the Model-View-Controller (MVC) architectural pattern. It allows users to book campus spaces, manage reservations, and prevent scheduling conflicts.

## Video Demo: https://www.youtube.com/watch?v=n28rjk8oU3c

## Team Members and Roles:
- ** Maryann (Person 1): Github & Integration 
- ** Dana (Person 2): Model / Backend
- ** Freddy (Person 3): Controller / Business Logic
- ** Austen (Person 4): UI / JavaFx
- ** Person 5: Testing & Quality Assurance 

## Architecture & Packages
- `model`: Core data structures and business objects (`Reservation`, `Room`, `User`).
- `view`: JavaFX user interface layouts and FXML forms.
- `controller`: Application logic bridging views and models.
- `persistence`: Data saving and loading handlers.
- `test`: JUnit test suites for model, logic, and acceptance testing.
