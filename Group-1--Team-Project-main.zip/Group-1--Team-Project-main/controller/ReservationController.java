package controller;

import model.Reservation;
import model.ReservationManager;
import model.Room;
import model.RoomManager;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class ReservationController {
    private ReservationManager reservationManager;
    private RoomManager roomManager;

    public ReservationController(ReservationManager reservationManager, RoomManager roomManager){
        this.reservationManager = reservationManager;
        this.roomManager = roomManager;
      }
    public boolean createReservation(LocalDate date,
                                     LocalTime startTime,
                                     LocalTime endTime,
                                     String roomId,
                                     String userId) {

        Reservation reservation =
                new Reservation(date, startTime, endTime, roomId, userId);

        return reservationManager.addReservation(reservation);
    }

    public boolean createReservation(
            LocalDate date,
            LocalTime startTime,
            LocalTime endTime,
            String roomId,
            String userId,
            String purpose
    ) {

        Reservation reservation =
                new Reservation(
                        date,
                        startTime,
                        endTime,
                        roomId,
                        userId,
                        purpose
                );

        return reservationManager
                .addReservation(reservation);
    }

    // GET ALL ROOMS
    public List<Room> getAllRooms() {

        return roomManager
                .getAllRooms();
    }

    // GET RESERVATIONS FOR A ROOM ON A DATE
    public List<Reservation> getReservationsForRoomAndDate(
            String roomId,
            LocalDate date
    ) {

        return reservationManager
                .getReservationsForRoomAndDate(
                        roomId,
                        date
                );
    }

    public List<Room> getRoomsByCapacity(int minimumCapacity) {
        return roomManager.filterByMinimumCapacity(minimumCapacity);
    }
    public boolean cancelReservation(Reservation reservation) {
        return reservationManager.cancelReservation(reservation);
    }
    public boolean modifyReservation(Reservation existingReservation,
                                     Reservation updatedReservation) {
        return reservationManager.modifyReservation(
                existingReservation, updatedReservation);
    }
    public List<Reservation> getReservationsForUser(String userId) {
        return reservationManager.getReservationsForUser(userId);
    }
}
